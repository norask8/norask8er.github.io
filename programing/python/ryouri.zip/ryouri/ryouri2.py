# -*- coding: utf-8 -*-
"""
Created on Sun Dec 20 15:27:55 2020

@author: nora_
"""

class MenuItem:
    def __init__(self,name,price):
        self.name = name
        self.price = price
        
    def info(self):
        return self.name + '.' + str(self.price) + '円'
    
    def get_total_price(self,count):
        total_price = self.price * count
        return total_price
    
class Food(MenuItem):#継承
    def __init__(self,name,price):
        super().__init__(name,price)#継承
        
    def info(self):
        return super().info() #returnしなきゃいけない
        
class Drink(MenuItem):
    def __init__(self,name,price):
        super().__init__(name,price)
        
    def info(self):
        return super().info() #return必須！！
        
food1 = Food('サンドウィッチ',500)
food2 = Food('チョコケーキ',400)
food3 = Food('シュークリーム',200)
foods = [food1,food2,food3]

drink1 = Drink('コーヒー',300)
drink2 = Drink('オレンジジュース',200)
drink3 = Drink('エスプレッソ',300)
drinks = [drink1,drink2,drink3]

print('フードメニュー')
index = 0
for food in foods:
    print(str(index) + ':' + food.info()) #リストの中の要素が順番に変数に代入され処理が行われる
    index += 1
    
print('')
print('ドリンクメニュー')
index = 0
for drink in drinks:
    print(str(index) + ':' + drink.info())
    index += 1
    
print('--------------------')

order = int(input('食べ物を選んでください:'))
selected_food = foods[order]
count = int(input('個数を選んでください:'))
food_count = count
order = int(input('飲み物を選んでください:'))
selected_drink = drinks[order]
count = int(input('個数を選んでください:'))
drink_count = count
    
result = selected_food.get_total_price(food_count) + selected_drink.get_total_price(drink_count)
print('合計は' + str(result) + '円です')
    
    
    
    
    